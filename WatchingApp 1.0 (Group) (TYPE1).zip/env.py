
#assign the source filepath
FILEPATH = "C:\\Users\\VMAK CAPITAL\\AppData\\Roaming\\MetaQuotes\\Terminal\\CEA95A93FC8D185DD2235895C53A5FFF\\MQL4\\Files\\"
#FILEPATH = ".\\Assets\\"

#assign the mastersheet filepath
MASTERFILEPATH = ".\\Assets\\"

#the measure is second
CYCLE_TIME = 60 * 60

# #the period of every index check time
# CHECK_INDEX_DURATION_TIME = 15 * 60

#the period of refresh or should I say update?
REFRESH_TIME = 5

#TYPE1MASTERSHEET.xlsx file name
TYPE1_MASTER_FILENAME = "MasterType1Sheet.xlsx"

#TYPE1MASTERSHEET.xlsx file name
GROUP_TYPE1_MASTER_FILENAME = "GroupMasterType1Sheet.xlsx"

#out put file names
#TYPE1 PRINT
TYPE1_PRINT = "Type1.csv"
